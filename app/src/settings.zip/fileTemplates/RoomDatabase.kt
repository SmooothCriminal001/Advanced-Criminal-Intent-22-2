#set($packageName = $PACKAGE_NAME.replace(".database", ""))
package ${packageName}.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import ${packageName}.${EntityClassName}

#set($lowerName = $NAME.toLowerCase())
//TODO: Add @Entity and @PrimaryKey to ${EntityClassName} class
@Database(entities = [ ${EntityClassName}::class ], version=1)
@TypeConverters(${NAME}TypeConverters::class)
abstract class ${NAME}Database : RoomDatabase() {
    abstract fun ${lowerName}Dao() : ${NAME}Dao
}