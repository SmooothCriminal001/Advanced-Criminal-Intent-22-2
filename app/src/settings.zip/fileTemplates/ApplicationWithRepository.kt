package ${PACKAGE_NAME}

import android.app.Application

//TODO: Add 'android:name=".${NAME}"' in AndroidManifest.xml's <application> tag
class ${NAME} : Application() {
    override fun onCreate() {
        super.onCreate()
        ${RepositoryClass}.initialize(this)
    }
}