#set($packageName = $PACKAGE_NAME.replace(".database", ""))
package ${packageName}.database

import androidx.room.TypeConverter
import java.util.*

class ${NAME}TypeConverters {
    @TypeConverter
    fun fromDate(date: Date): Long {
        return date.time
    }

    @TypeConverter
    fun toDate(millisSinceEpoch: Long): Date {
        return Date(millisSinceEpoch)
    }
}