#set($packageName = $PACKAGE_NAME.replace(".database", ""))
package ${packageName}.database

import androidx.room.Dao
import kotlinx.coroutines.flow.Flow
import androidx.room.Query
import ${packageName}.${NAME}
import java.util.*

#set($lowerName = $NAME.toLowerCase())
@Dao
interface ${NAME}Dao {
    @Query("SELECT * FROM ${lowerName}")
    fun get${EntityClassName}s() : Flow<List<${EntityClassName}>>
    //TODO: paste where required: fun get${EntityClassName}s() : Flow<List<${EntityClassName}>> = database.${lowerName}Dao().get${EntityClassName}s()
    
    @Query("SELECT * FROM ${lowerName} WHERE id=(:id)")
    fun get${EntityClassName} (id: UUID) : Flow<${EntityClassName}>
    //TODO: paste where required: fun get${EntityClassName} (id: java.util.UUID) : Flow<${EntityClassName}> = database.${lowerName}Dao().get${EntityClassName}(id)   
}