package ${PACKAGE_NAME}

import ${ViewModelClassName}
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import ${PACKAGE_NAME}.databinding.${BindingClassName}

/* COROUTINE & Lifecycle imports
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
*/

class ${NAME}: Fragment() {

    private val viewModel : ${ViewModelClassName} by viewModels()
    private var _binding: ${BindingClassName}? = null
    private val binding
        get() = checkNotNull(_binding) {
            "Cannot access binding because it is null. Is the view visible?"
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = ${BindingClassName}.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        /* Include proper dependencies first for this
        //Things to be done in a coroutine tied to this fragment's lifecycle
        viewLifecycleOwner.lifecycleScope.launch {
            //Things that have to be done every time a fragment hits a specific lifecycle
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
            
            }
        }
        */
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}