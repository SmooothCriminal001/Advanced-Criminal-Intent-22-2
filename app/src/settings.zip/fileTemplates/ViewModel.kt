package ${PACKAGE_NAME}

import androidx.lifecycle.ViewModel

class ${NAME} : ViewModel(){
	init {
		#[[$END$]]#
	}
	
	override fun onCleared() {
		super.onCleared()
	}
}