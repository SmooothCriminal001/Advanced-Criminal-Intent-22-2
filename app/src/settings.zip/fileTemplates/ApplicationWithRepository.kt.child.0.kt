package ${PACKAGE_NAME}

import android.content.Context

class ${RepositoryClass} private constructor(context: Context) {

     companion object {
        private var INSTANCE: ${RepositoryClass}? = null

         fun initialize(context: Context) {
             if (INSTANCE == null) {
                 INSTANCE = ${RepositoryClass}(context)
             }
        }

         fun get(): ${RepositoryClass} {
            return INSTANCE ?:
            throw IllegalStateException("${RepositoryClass} must be initialized")
        }
    }
}