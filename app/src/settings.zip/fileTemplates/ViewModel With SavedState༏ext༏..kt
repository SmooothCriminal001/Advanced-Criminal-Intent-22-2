package ${PACKAGE_NAME}

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel

const val ${SavedStateHandleKey} = "${SavedStateHandleKey}"
class ${NAME}(private val savedStateHandle: SavedStateHandle) : ViewModel(){
	
	private var ${VariableName}
		get() = savedStateHandle.get(${SavedStateHandleKey}) ?: ${DefaultVariableValue}
		set(value) = savedStateHandle.set(${SavedStateHandleKey}, value)

	
	init {
		#[[$END$]]#
	}
	
	override fun onCleared() {
		super.onCleared()
	}
}